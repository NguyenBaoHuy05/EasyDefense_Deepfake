import json
import os
import argparse
import torch
import numpy as np
import random
from PIL import Image
import torch
from torchvision import transforms as tf
import numpy as np
import importlib
from diffusers import DDIMScheduler

import utils.utils_general_H as utils

TARGET_SIZE = 512
to_pil = tf.ToPILImage()
to_tensor = tf.ToTensor()
tform = tf.Compose(
    [
        tf.Resize(TARGET_SIZE),
        tf.CenterCrop(TARGET_SIZE),
        tf.ToTensor(), 
    ]
)
Image_to_tensor = lambda x: 2.0*tform(x)-1.0
path_to_tensor = lambda x: Image_to_tensor(Image.open(x).convert('RGB')) 
is_vae_latent = lambda x: x.shape[1]!=3 

class ATTACK:
    def __init__(self,config) -> None:
        if type(config) == dict:
            self.config = config
        print(self.config)
        self.method = self.load_method()
        pass
    def preprocess(self, x):
        if self.config['attack']['args']['preprocess_full_overwrite']:
            raise NotImplementedError
        if isinstance(x,Image.Image):
            if self.config['attack']['args']['precision']=='float32':
                x = Image_to_tensor(x).unsqueeze(0).to("cuda").float()
            elif self.config['attack']['args']['precision']=='float16':
                x = Image_to_tensor(x).unsqueeze(0).to("cuda").half() 
        elif isinstance(x,str):
            if self.config['attack']['args']['precision']=='float32':
                x = path_to_tensor(x).unsqueeze(0).to("cuda").float()
            elif self.config['attack']['args']['precision']=='float16':
                x = path_to_tensor(x).unsqueeze(0).to("cuda").half() 
        elif isinstance(x,torch.Tensor):
            pass
        else:
            raise TypeError('x must be Image or Tensor or str')
        x=self.method.custom_preprocess(x)
        return x
    
    def postprocess(self, x):
        if self.config['attack']['args']['postprocess_full_overwrite']:
            x=self.method.custom_postprocess(x)
            return x
        else:
            x=self.method.custom_postprocess(x)
            if is_vae_latent(x): 
                x = self.method.decode(x) 
            else:
                pass 
            x = (x/2.0+0.5).clamp(0,1) 
            x = to_pil(x[0]).convert('RGB') 
            
        return x
    def __call__(self, x,**attack_args):
        x = self.preprocess(x) 
        x = self.attack(source_latents=x, **attack_args) 
        x = self.postprocess(x)
        return x
    
    def attack(self,source_latents,**attack_args):
        return self.method(source_latents=source_latents,target_latents=source_latents.clone(),**attack_args)
    
    def load_model(self):
        path = self.config['model']['path']
        if self.config['attack']['args']['precision']=='float32':
            pipe = utils.CustomDiffusionPipeline.from_pretrained(path,torch_dtype=torch.float32)
        elif self.config['attack']['args']['precision']=='float16':
            pipe = utils.CustomDiffusionPipeline.from_pretrained(path,torch_dtype=torch.float16) 
        pipe.scheduler = DDIMScheduler.from_pretrained(path, subfolder="scheduler",)
        pipe = pipe.to("cuda")
        return pipe
    
    def load_method(self):
        method = importlib.import_module('attack.{}'.format(self.config['attack']['name']))
        importlib.reload(method)

        model=self.load_model()
        method = method.METHOD2(model,**self.config['attack']['args']) 
        return method
    def debugging(self, x,**attack_args):
        x = self.preprocess(x) 
        x = self.attack(source_latents=x, **attack_args) 
        x = self.postprocess(x)
        return x
    
def setup_seed(seed=1234):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False



image_save_paths={
    'DIA_PT':'DIA_PT',
    "DIA_R":'DIA_R',    
    }

attack_dict={

}

def attack(attack_method, **hparam):
    """
    attack_method: the attack method
    image_path: the path of the image to be attacked
    hparam: the hyperparameters of the attack method
    """
    # print(f"editing image [{image_path}] with [{attack_method}]")
    if 'method_name' in attack_dict[attack_method]:
        test_config={"model":{"path":"CompVis/stable-diffusion-v1-4"},"attack":{"name":attack_dict[attack_method]['method_name'],"args":attack_dict[attack_method]}}
    else:
        test_config={"model":{"path":"CompVis/stable-diffusion-v1-4"},"attack":{"name":attack_method,"args":attack_dict[attack_method]}}
    if 'target_obj' in hparam:
        test_config['attack']['args']['forward_uncond_prompt'] = f"a photo of {hparam['target_obj']}"
    attack = ATTACK(test_config)

    return attack
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--attack_setting_path', type=str, default="attack_setting.json", help="Path to attack settings file")
    parser.add_argument('--attack_method', type=str, default='DIA_PT', help="Attack method to use")
    parser.add_argument('--image_path', type=str, required=True, help="Path to image for attack")
    parser.add_argument('--output_path', type=str, default="./output", help="Path to save output image")
    parser.add_argument('--target_obj', type=str, default=None, help="Target object prompt")
    parser.add_argument('--seed', type=int, default=1234, help="Random seed")
    args = parser.parse_args()
    
    # Load attack settings
    with open(args.attack_setting_path) as f:
        attack_dict = json.load(f)
    
    # Set seed
    setup_seed(args.seed)
    
    # Initialize attack method
    method = attack(args.attack_method, target_obj=args.target_obj)
    
    print(f"Attacking image [{args.image_path}] with [{args.attack_method}]")
    
    # Execute attack
    torch.cuda.empty_cache()
    edited_image = method(args.image_path)
    
    # Save result
    if not os.path.exists(args.output_path):
        os.makedirs(args.output_path)
    
    output_filename = os.path.basename(args.image_path)
    output_filename = os.path.splitext(output_filename)[0] + ".png"
    output_path = os.path.join(args.output_path, output_filename)
    
    edited_image.save(output_path)
    print(f"Result saved to {output_path}")